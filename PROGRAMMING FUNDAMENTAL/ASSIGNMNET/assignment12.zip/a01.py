def code_holder(num1, num2):
    v = 0
    #### YOUR CODE GOES HERE ####
    #### make sure you save the return value in the variable: v
    



    #### DO NOT WRITE AFTER THIS LINE

    return v
